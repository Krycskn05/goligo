'use client';
import {useCallback,useEffect,useMemo,useRef,useState,type ReactNode} from 'react';
import {ArrowRight,Check,Lightbulb,Lock,RotateCcw,Trash2,Volume2} from 'lucide-react';
import type {StudyLanguage} from '@/lib/study-languages';
import type {TopicProgress} from '@/lib/progress';
import {siteClipUrls,warmClip} from '@/lib/site-voices';
import {acceptsAnswer,acceptsExact,portraitSrc,sayText,speakerVoice,voiceOwner,withSpeakers,type GapLine,type SayItem,type Step} from '@/lib/willkommen-course';
import type {L1AScoreMap,L1PartId} from '@/lib/willkommen-progress';
import {useAnswerSound,useGermanSpeech} from './study-shared';
import {PaulHoca} from './paul-hoca';
import {mixedOrder} from '@/lib/mixed-order';

/*
 * Pieces shared by Lektion 1's lesson pages (Teil A in app/willkommen-study.tsx, Teil B in app/willkommen-b-steps.tsx):
 * speech with a voice per person, the say button, headings and notes, and the exercise types both parts use.
 */

/** Site speech plus "read these one after the other" (dialogues, spelling, the learner's own sentences). A text with a
 * speaker (`who`, see `speakers` in lib/willkommen-course.ts) is read with that person's own voice — a man by a man, a
 * woman by a woman; a text in which a person names themselves ("Ich heiße Sabine Krüger.") is always read by that person
 * (`voiceOwner`, 31 October 2026); everything else with the learner's chosen voice. `slow` reads slowly (letters when spelling). */
/** Read-along (the learner asked, 2 November 2026): while a dialogue is read one line after the other, the line being
 * read is marked (`.l1a-reading`) and the page scrolls with it, so the learner sees each sentence as it is spoken. The
 * line is found by its German text (`.l1a-de` inside `.l1a-line`, gaps count with the word that fills them); a spoken
 * text with no such line on the page changes nothing. Scrolling waits while the learner scrolls by hand. */
const READING='l1a-reading';
const plain=(text:string)=>text.replace(/\u00a0/g,' ').replace(/\s+/g,' ').replace(/\s+([.,!?;:])/g,'$1').trim().toLowerCase();
/** The words of a line as they would be read: typed gaps count with what is written in them; hints and open word boxes do not. */
function spokenText(node:Node):string{
 if(node.nodeType===Node.TEXT_NODE)return node.nodeValue??'';
 if(!(node instanceof HTMLElement))return '';
 if(node instanceof HTMLInputElement||node instanceof HTMLTextAreaElement)return node.value;
 if(node.getAttribute('aria-hidden')==='true'||node.classList.contains('l1a-hint')||node.classList.contains('l1a-choice-menu'))return '';
 return [...node.childNodes].map(spokenText).join('');
}
export function findReadLine(text:string,after?:Element|null):HTMLElement|null{
 const want=plain(text);if(!want)return null;
 const lines=[...document.querySelectorAll<HTMLElement>('.l1a-line')];
 const textOf=(line:HTMLElement)=>{const de=line.querySelector('.l1a-de');return de?plain(spokenText(de)):'';};
 const exact=lines.filter(line=>textOf(line)===want);
 // A line read a little shorter than it is written (a Turkish word left out): most of its words are on the line.
 const words=(value:string)=>value.replace(/[^\p{L}\p{N}\s]/gu,' ').split(/\s+/).filter(Boolean);
 const wanted=words(want);
 const share=(line:HTMLElement)=>{const have=new Set(words(textOf(line)));return wanted.filter(word=>have.has(word)).length/wanted.length;};
 let loose=exact;
 if(!loose.length&&wanted.length>=4){const scored=lines.map(line=>({line,score:share(line)})).filter(item=>item.score>=0.75);const best=Math.max(0,...scored.map(item=>item.score));loose=scored.filter(item=>item.score===best).map(item=>item.line);}
 if(!loose.length)return null;
 // The same sentence twice on a page: take the first one after the line read before.
 const later=after?loose.find(line=>after.compareDocumentPosition(line)&Node.DOCUMENT_POSITION_FOLLOWING):undefined;
 return later??loose[0];
}
function clearReading(){document.querySelectorAll('.'+READING).forEach(line=>line.classList.remove(READING));}
function showReading(line:HTMLElement,scroll:boolean){
 clearReading();line.classList.add(READING);
 if(!scroll)return;
 const rect=line.getBoundingClientRect();const height=window.innerHeight||document.documentElement.clientHeight;
 if(rect.top>=height*0.18&&rect.bottom<=height*0.82)return; // already in the middle of the screen
 const still=window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
 line.scrollIntoView({block:'center',behavior:still?'auto':'smooth'});
}
export type Speech={speak:(item:SayItem)=>void;speakAll:(items:SayItem[])=>void;busy:boolean;activeText?:string;stop:()=>void;prepare:()=>void;warm?:(items:readonly SayItem[])=>void};
export function useLessonSpeech():Speech&{warning?:string}{
 const german=useGermanSpeech('de');const {speak,busy,activeText,stop,prepare,warning,siteVoices}=german;
 const voices=useRef(siteVoices);voices.current=siteVoices;
 const preferred=useRef(german.voiceName);preferred.current=german.voiceName;
 // Loads the clips of what is on the page before the tap (30 October 2026); runs again once the site voices are known.
 const warm=useCallback((items:readonly SayItem[])=>{if(!siteVoices.length)return;for(const item of items){const text=sayText(item);if(!text.trim())continue;const who=voiceOwner(item);const url=siteClipUrls(speakerVoice(who,siteVoices)??preferred.current,text)[0];if(url)warmClip(url);}},[siteVoices]);
 const say=useCallback((item:SayItem)=>{const who=voiceOwner(item);const slow=typeof item!=='string'&&!!item.slow;speak(sayText(item),slow,speakerVoice(who,voices.current));},[speak]);
 const queue=useRef<SayItem[]>([]);const waiting=useRef<ReturnType<typeof setTimeout>|null>(null);
 const following=useRef(false);const lastLine=useRef<HTMLElement|null>(null);const handScroll=useRef(false);
 const busyRef=useRef(busy);
 const next=useCallback(()=>{
  const item=queue.current.shift();if(!item)return;
  say(item);
  // If the voice never starts (no sound support), go on after a moment so the queue never sticks.
  waiting.current=setTimeout(()=>{waiting.current=null;if(!busyRef.current)next();},1500);
 },[say]);
 useEffect(()=>{const was=busyRef.current;busyRef.current=busy;if(busy&&waiting.current){clearTimeout(waiting.current);waiting.current=null;}if(was&&!busy)next();},[busy,next]);
 const speakAll=useCallback((items:SayItem[])=>{stop();queue.current=items.filter(item=>sayText(item).trim());following.current=true;lastLine.current=null;handScroll.current=false;next();},[stop,next]);
 const speakOne=useCallback((item:SayItem)=>{queue.current=[];following.current=false;clearReading();say(item);},[say]);
 const stopAll=useCallback(()=>{queue.current=[];following.current=false;clearReading();if(waiting.current){clearTimeout(waiting.current);waiting.current=null;}stop();},[stop]);
 // Read-along: mark the line being read and keep it on the screen; the mark goes when the reading ends.
 useEffect(()=>{
  if(!following.current)return;
  if(busy&&activeText){const line=findReadLine(activeText,lastLine.current);if(line){lastLine.current=line;showReading(line,!handScroll.current);}return;}
  if(!busy&&!queue.current.length&&!waiting.current){following.current=false;clearReading();}
 },[busy,activeText]);
 useEffect(()=>{
  const hand=()=>{if(following.current)handScroll.current=true;};
  window.addEventListener('wheel',hand,{passive:true});window.addEventListener('touchmove',hand,{passive:true});
  return()=>{window.removeEventListener('wheel',hand);window.removeEventListener('touchmove',hand);clearReading();};
 },[]);
 useEffect(()=>()=>{if(waiting.current)clearTimeout(waiting.current);},[]);
 return useMemo(()=>({speak:speakOne,speakAll,busy,activeText,stop:stopAll,prepare,warning,warm}),[speakOne,speakAll,busy,activeText,stopAll,prepare,warning,warm]);
}

export type Sound=ReturnType<typeof useAnswerSound>;
/** What every step gets: `onGo` opens a step of the same part (a negative number: the contents page), `onPart` a step of another part. */
export type StepProps={step:Step;speech:Speech;sound:Sound;scores:L1AScoreMap;progress:TopicProgress;onScore:(id:string,right:number,total:number)=>void;onGo:(index:number)=>void;onPart:(part:L1PartId,index:number)=>void;language:StudyLanguage;setInnerNext?:(next:(()=>boolean)|null)=>void;runKey?:string};
/** The page's "İleri" goes on inside an exercise that shows one item at a time (the learner asked, 30 October 2026, first
 * for Lektion 15A, then for every lesson): `next` returns true when it opened the exercise's next item (or ended it), false
 * when the exercise is over and the page may open the next step. Lektion 1 and 15 pass `setInnerNext`. */
export function useInnerNext(setInnerNext:StepProps['setInnerNext'],next:()=>boolean){
 const latest=useRef(next);latest.current=next;
 useEffect(()=>{if(!setInnerNext)return;setInnerNext(()=>latest.current());return()=>setInnerNext(null);},[setInnerNext]);
}
/** An exercise or a test that was left in the middle goes on where it was (the learner asked, 30 October 2026): its state
 * stays in the browser under the page's `runKey` (lernkoko-l1a-run, lernkoko-l15a-run …) and the step id, and is
 * dropped once it is finished. `fix` checks a saved state against the lesson (and may move it on); null = start anew. */
export function readRun<T>(key:string|undefined,id:string,fix:(value:Record<string,unknown>)=>T|null):T|null{
 if(!key)return null;
 try{const all=JSON.parse(localStorage.getItem(key)??'{}');const value=all&&typeof all==='object'?all[id]:null;return value&&typeof value==='object'?fix(value):null;}catch{return null;}
}
export function saveRun(key:string|undefined,id:string,value:unknown){
 if(!key)return;
 try{const all=JSON.parse(localStorage.getItem(key)??'{}');const next=all&&typeof all==='object'?all:{};
  if(value==null)delete next[id];else next[id]=value;
  if(Object.keys(next).length)localStorage.setItem(key,JSON.stringify(next));else localStorage.removeItem(key);}catch{}
}
/** Saves a run whenever it changes (null: not started yet, or finished). */
export function useRunSave(key:string|undefined,id:string,value:unknown){
 const text=JSON.stringify(value??null);
 useEffect(()=>{saveRun(key,id,JSON.parse(text));},[key,id,text]);
}
const sameItems=(a:unknown,b:readonly string[])=>Array.isArray(a)&&a.length===b.length&&b.every(item=>a.includes(item));

/* ---------- small pieces ---------- */
/** A listen button. `secret`: a listening exercise, so the button's name does not give the answer away. */
export function Say({text,who,slow,speech,label='Dinle',wide=false,secret=false}:{text:string;who?:string;slow?:boolean;speech:Speech;label?:string;wide?:boolean;secret?:boolean}){
 const warm=speech.warm;useEffect(()=>{warm?.([{text,who}]);},[warm,text,who]);
 const playing=speech.busy&&speech.activeText===text;
 return <button type="button" className={(wide?'btn secondary small l1a-say-wide':'l12-say')+(playing?' playing':'')} disabled={speech.busy&&!playing} aria-label={secret?(label==='Dinle'?label:'Dinle '+label):label+': '+text} title={label} data-who={who} onClick={()=>speech.speak({text,who,slow})}><Volume2 size={18} aria-hidden="true"/>{wide&&label}</button>;
}
export function Phrases({items,speech}:{items:readonly (readonly [string,string])[];speech:Speech}){
 return <>{items.map(([de,tr])=><div className="l1a-phrase" key={de}><div className="l1a-phrase-text"><span className="l1a-de" lang="de" dir="ltr">{de}</span><span className="l1a-tr">{tr}</span></div><Say text={de} speech={speech}/></div>)}</>;
}
export const Note=({children}:{children:ReactNode})=><div className="l1a-note"><PaulHoca pose="tip" className="l1a-paul"/><p>{children}</p></div>;
/** `**bold**` inside a text. */
export function Rich({text}:{text:string}){const parts=text.split(/(\*\*[^*]+\*\*)/g);return <>{parts.map((part,i)=>part.startsWith('**')&&part.endsWith('**')&&part.length>4?<b key={i}>{part.slice(2,-2)}</b>:part)}</>;}
/** A step's heading (h2: the notebook's left page holds the h1 title of the part). */
export function Heading({children}:{children:ReactNode}){return <h2 id="l1a-heading" tabIndex={-1} className="l1a-heading">{children}</h2>;}
export function Portrait({who,name}:{who:string;name:string}){return <img className="l1a-portrait" src={portraitSrc(who)} alt={name} width={64} height={64} loading="lazy" decoding="async"/>;}
export function shuffle<T>(list:readonly T[]):T[]{const out=list.slice();for(let i=out.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[out[i],out[j]]=[out[j],out[i]];}return out;}
export {mixedOrder};

/* ---------- exercises ---------- */
export type Feedback={ok:boolean;text:string;info?:boolean}|null;
/** The line under an exercise once every row is answered (the learner asked, 2 November 2026): never red, because the last
 * answer may well have been right; a full score is green. */
export function scoreFeedback(right:number,total:number):Feedback{return right===total?{ok:true,text:`Hepsi doğru! ${right} / ${total}`}:{ok:true,info:true,text:`Bitti: ${right} / ${total} doğru. Yanlışların doğrusu yeşil.`};}
export function FeedbackLine({feedback}:{feedback:Feedback}){return <p className={'l1a-feedback'+(feedback?feedback.info?' info':feedback.ok?' ok':' bad':'')} role="status" aria-live="polite">{feedback?.text??''}</p>;}
/** Gaps that check themselves (the learner asked, 30 October 2026: no "Kontrol et", no "Cevapları göster"): a right
 * answer turns green at once; a wrong one turns red when it is final (the learner leaves the box or presses Enter, every
 * letter cell is filled, a word is chosen) and the right answer stays next to it until it is fixed. The score counts the
 * first try of every gap; `onDone` runs once, when every gap is right. */
export type SelfCheckResult='right'|'wrong'|'open';
export function useSelfCheck(count:number,isRight:(i:number,value:string)=>boolean,onDone:(firstRight:number)=>void){
 const fresh=()=>({values:Array.from({length:count},()=>''),state:Array.from({length:count},():boolean|null=>null),hinted:Array.from({length:count},()=>false)});
 const [view,setView]=useState(fresh);
 const latest=useRef(view);latest.current=view;
 const first=useRef<(boolean|null)[]>(Array.from({length:count},()=>null));const scored=useRef(false);
 const change=(i:number,value:string,final=false):SelfCheckResult=>{
  const old=latest.current;const filled=value.trim().length>0;
  const right=filled&&isRight(i,value);const wrong=!right&&final&&filled;
  const next={values:old.values.slice(),state:old.state.slice(),hinted:old.hinted.slice()};
  next.values[i]=value;next.state[i]=right?true:wrong?false:null;if(wrong)next.hinted[i]=true;
  if((right||wrong)&&first.current[i]===null)first.current[i]=right;
  latest.current=next;setView(next);
  if(right&&!scored.current&&next.state.every(value=>value===true)){scored.current=true;onDone(first.current.filter(value=>value===true).length);}
  return right?'right':wrong?'wrong':'open';
 };
 const leave=(i:number):SelfCheckResult=>latest.current.state[i]===true?'right':change(i,latest.current.values[i],true);
 const reset=()=>{const next=fresh();latest.current=next;setView(next);first.current=Array.from({length:count},()=>null);scored.current=false;};
 return {values:view.values,state:view.state,hinted:view.hinted,change,leave,reset,
  stateNow:(i:number)=>latest.current.state[i],anyWrong:()=>latest.current.state.some(value=>value===false),isDone:()=>scored.current};
}
/** The line under a self-checking exercise after a wrong answer (cleared once nothing is red). */
export function selfCheckNote(result:SelfCheckResult,self:{anyWrong:()=>boolean;isDone:()=>boolean},text:string,setFeedback:(feedback:Feedback)=>void){
 if(result==='wrong')setFeedback({ok:false,text});else if(!self.anyWrong()&&!self.isDone())setFeedback(null);
}
/** Finishes an exercise: saves the score, plays the sound and reads the solution after a full score. */
/** The end of an exercise: saves the score and plays the sound. `lastOk` is the last answer (rows answered one by one):
 * the sound goes by that answer, never by the whole score (the learner asked, 2 November 2026: six right answers ended
 * with the wrong sound because of an earlier mistake). Without `lastOk` (one check for everything) it goes by the score.
 * `say` is read after the sound: the whole solution, or the last row's sentence. */
export function useFinish(props:StepProps){
 const {sound,speech,onScore,step}=props;
 return useCallback((right:number,total:number,say?:SayItem[],lastOk?:boolean)=>{
  onScore(step.id,right,total);
  const read=()=>{if(say?.length)speech.speakAll(say);};
  if(lastOk??right===total)sound.correct(read);else sound.wrong(lastOk===undefined?undefined:read);
 },[sound,speech,onScore,step.id]);
}
/** Exercises go in order (the learner asked, 30 October 2026): an exercise opens once the ones before it are done, and
 * the test and Konuş open once every exercise of the part is done. Steps already done stay open. `open` is the first
 * exercise still to do (null when all are done). */
export function exerciseLock(groups:readonly {id:string;ids:readonly string[]}[],steps:readonly {id:string}[],scores:L1AScoreMap){
 const exercises=groups.find(group=>group.id==='alistirmalar')?.ids??[];
 const open=exercises.find(id=>!scores[id])??null;
 const locked=new Set<string>();
 if(open){
  exercises.slice(exercises.indexOf(open)+1).forEach(id=>{if(!scores[id])locked.add(id);});
  groups.filter(group=>group.id==='test'||group.id==='konus').forEach(group=>group.ids.forEach(id=>locked.add(id)));
 }
 return {open,openIndex:open?steps.findIndex(step=>step.id===open):-1,locked,isExercise:(id:string)=>exercises.includes(id)};
}
/** What a locked step shows instead of itself (opened from its address or an old bookmark). */
export function LockedStep({openLabel,onOpen}:{openLabel:string;onOpen:()=>void}){
 return <div className="l1a-locked" role="status"><span className="l1a-locked-icon" aria-hidden="true"><Lock size={26}/></span>
  <p>Bu bölüm henüz kilitli. Önce alıştırmaları sırayla bitir.</p>
  <button type="button" className="btn small" onClick={onOpen}>Sıradaki alıştırma: {openLabel}</button></div>;
}
/** A gap filled from a box of words (the learner chose it, 30 October 2026, option B): a tap on the gap opens the words
 * right under it as big buttons, a tap on a word puts it in and closes the box (Escape or a tap elsewhere closes it too).
 * Every word always looks the same, even when it is already in another gap (the learner asked, 2 November 2026: a faded
 * word gave the answer away). Used in every lesson instead of a drop-down list. */
export function WordChoice({value,options,state,label,onChoose}:{value:string;options:readonly string[];state:boolean|null;label:string;onChoose:(value:string)=>void}){
 const [open,setOpen]=useState(false);
 const box=useRef<HTMLSpanElement>(null);const menu=useRef<HTMLSpanElement>(null);
 useEffect(()=>{if(!open)return;
  const element=menu.current;
  if(element){
   // Keep the box on the screen: near the right edge it moves left (near the left edge, right).
   element.style.transform='';const rect=element.getBoundingClientRect();const over=rect.right-(window.innerWidth-8);const under=8-rect.left;
   if(over>0)element.style.transform=`translateX(${-Math.min(over,Math.max(0,rect.left-8))}px)`;else if(under>0)element.style.transform=`translateX(${under}px)`;
   element.scrollIntoView({block:'nearest',behavior:'smooth'});
   element.querySelector<HTMLButtonElement>('button.on')?.focus({preventScroll:true});
  }
  const away=(event:PointerEvent)=>{if(!box.current?.contains(event.target as Node))setOpen(false);};
  const key=(event:KeyboardEvent)=>{if(event.key==='Escape'){setOpen(false);box.current?.querySelector<HTMLButtonElement>('.l1a-choice-slot')?.focus();}};
  document.addEventListener('pointerdown',away);document.addEventListener('keydown',key);
  return()=>{document.removeEventListener('pointerdown',away);document.removeEventListener('keydown',key);};
 },[open]);
 return <span className={'l1a-choice'+(open?' open':'')} ref={box}>
  <button type="button" className={'l1a-choice-slot'+(value?' filled':'')+(state===true?' ok':state===false?' bad':'')} lang="de" aria-haspopup="true" aria-expanded={open} aria-label={value?label+': '+value:label} onClick={()=>setOpen(current=>!current)}>{value||' '}</button>
  {open&&<span className="l1a-choice-menu" ref={menu} role="group" aria-label={label}>{options.map(word=><button type="button" key={word} lang="de" className={'l1a-choice-word'+(word===value?' on':'')} onClick={()=>{onChoose(word);setOpen(false);}}>{word}</button>)}</span>}
 </span>;
}
/** A typed gap as one cell per missing letter inside the word (the learner chose it, 30 October 2026, option A). One real
 * input lies over the cells, so the phone keyboard, deleting and pasting work as usual; the caret always stays at the end. */
function LetterCells({value,size,state,label,exact,inputRef,onChange}:{value:string;size:number;state:boolean|null;label:string;exact:boolean;inputRef:(element:HTMLInputElement|null)=>void;onChange:(value:string)=>void}){
 const [focus,setFocus]=useState(false);
 const letters=Array.from(value);const count=Math.max(size,letters.length);
 const toEnd=(element:HTMLInputElement)=>{const end=element.value.length;try{element.setSelectionRange(end,end);}catch{}};
 return <span className={'l1a-cells'+(state===true?' ok':state===false?' bad':'')+(focus?' focus':'')}>
  {Array.from({length:count},(_,k)=><i key={k} className={focus&&state!==true&&k===Math.min(letters.length,count-1)?'cur':undefined} aria-hidden="true">{letters[k]??''}</i>)}
  <input ref={inputRef} className="l1a-cells-input" value={value} lang="de" dir="ltr" autoCapitalize={exact?'sentences':'off'} autoComplete="off" autoCorrect="off" spellCheck={false} maxLength={size+3} aria-label={label}
   onFocus={event=>{setFocus(true);const element=event.currentTarget;requestAnimationFrame(()=>toEnd(element));}} onBlur={()=>setFocus(false)}
   onClick={event=>toEnd(event.currentTarget)} onChange={event=>onChange(event.target.value)}/>
 </span>;
}
/** Gaps in a text: letters inside a word, whole sentences (wide) or a word chosen from a box. `speakers` read the
 * solution as a little dialogue (lines alternate a, b), each line by its own person. Every gap checks itself
 * (useSelfCheck); when all are right the solution is read. */
export function GapExercise(props:StepProps&{kicker:string;title:string;lead?:string;before?:ReactNode;lines:GapLine[];wide?:boolean;choices?:string[];bank?:boolean;say:SayItem[];speakers?:{a:string;b:string};exact?:boolean;cells?:boolean}){
 const {kicker,title,before,lines,wide=false,choices,bank=false,sound,speech,speakers,exact=false,cells=false,onScore,step}=props;
 const refs=useRef<(HTMLInputElement|null)[]>([]);
 const accepts=exact?acceptsExact:acceptsAnswer;
 const say=useMemo(()=>speakers?withSpeakers(props.say.map(item=>typeof item==='string'?item:item.text),speakers):props.say,[props.say,speakers]);
 const gaps=useMemo(()=>lines.flatMap((line,l)=>line.answers.map((answers,g)=>({line:l,gap:g,answers}))),[lines]);
 const [feedback,setFeedback]=useState<Feedback>(null);
 const warm=speech.warm;useEffect(()=>{warm?.(say);},[warm,say]); // the solution read at the end, loaded early
 // The box in mixed order, the same in the list above and in every gap (`bank` writes the list as the lead).
 const [box]=useState(()=>choices?mixedOrder(choices,gaps.map(gap=>gap.answers[0])):undefined);
 const lead=bank&&box?'Kelimeler: '+box.join(' · '):props.lead;
 const at=(l:number,g:number)=>gaps.findIndex(item=>item.line===l&&item.gap===g);
 const letters=(text:string)=>Array.from(text).length;
 const total=gaps.length;
 const self=useSelfCheck(total,(i,value)=>accepts(value,gaps[i].answers)&&(!cells||wide||letters(value)>=letters(gaps[i].answers[0])),firstRight=>{
  onScore(step.id,firstRight,total);
  setFeedback({ok:true,text:firstRight===total?'Hepsi doğru!':`Hepsi doğru! İlk denemede ${firstRight} / ${total} doğruydu.`});
  sound.correct(()=>{if(say.length)speech.speakAll(say);});
 });
 const note=(result:SelfCheckResult)=>selfCheckNote(result,self,choices?'Kırmızıyı değiştir: başka bir kelime dene.':'Kırmızıyı düzelt; doğrusu yanında yazıyor.',setFeedback);
 const prepare=()=>{sound.prepare();speech.prepare();};
 const focusNext=(i:number)=>{const target=gaps.findIndex((_,k)=>k>i&&self.stateNow(k)!==true);if(target>=0)refs.current[target]?.focus();};
 // Letter cells: final when every cell is filled; a right word opens the next gap.
 const typeCells=(i:number,text:string)=>{prepare();const result=self.change(i,text,letters(text)>=letters(gaps[i].answers[0]));note(result);if(result==='right')focusNext(i);};
 const chooseWord=(i:number,word:string)=>{prepare();note(self.change(i,word,true));};
 const typeText=(i:number,text:string)=>{prepare();note(self.change(i,text));};
 const field=(l:number,g:number)=>{const i=at(l,g);const state=self.state[i];const cls='l1a-gap'+(wide?' wide':'')+(state===true?' ok':state===false?' bad':'');
  const input=choices?<WordChoice value={self.values[i]} options={box??choices} state={state} label={`Boşluk ${i+1}`} onChoose={word=>chooseWord(i,word)}/>
   :cells&&!wide?<LetterCells value={self.values[i]} size={letters(gaps[i].answers[0])} state={state} label={`Boşluk ${i+1}`} exact={exact} inputRef={element=>{refs.current[i]=element;}} onChange={text=>typeCells(i,text)}/>
   :<input ref={element=>{refs.current[i]=element;}} className={cls} value={self.values[i]} lang="de" dir="ltr" autoCapitalize={exact?'sentences':'off'} autoComplete="off" spellCheck={false} placeholder={wide?'Buraya yaz…':''} aria-label={`Boşluk ${i+1}`} enterKeyHint="next"
     onChange={event=>typeText(i,event.target.value)} onBlur={()=>note(self.leave(i))} onKeyDown={event=>{if(event.key==='Enter'){event.preventDefault();note(self.leave(i));focusNext(i);}}}/>;
  return <span className="l1a-gap-wrap" key={g}>{input}{!choices&&self.hinted[i]&&state!==true&&<span className="l1a-hint" lang="de">→ {gaps[i].answers[0]}</span>}</span>;};
 const line=(item:GapLine,l:number)=>{const parts=item.text.split('___');return <span className="l1a-de l1a-gap-text" lang="de" dir="ltr">{parts.map((part,g)=><span key={g}>{part}{g<parts.length-1&&field(l,g)}</span>)}</span>;};
 return <>
  <p className="kicker" lang="de">{kicker}</p><Heading>{title}</Heading>{lead&&<p className="l1a-tr">{lead}</p>}{before}
  <div className="l1a-dialogue">{lines.map((item,l)=>item.who?<div className={'l1a-line '+item.who} key={l}><div className="l1a-bubble">{line(item,l)}</div></div>:<div className={'l1a-row'+(item.say?' l1a-row-say':'')} key={l}>{item.say&&<Say text={sayText(item.say)} who={typeof item.say==='string'?undefined:item.say.who} speech={speech} label={String(l+1)} wide secret/>}{line(item,l)}</div>)}</div>
  {/* No check or show-answers buttons (the learner asked, 30 October 2026): every gap checks itself. */}
  <FeedbackLine feedback={feedback}/>
 </>;
}
/** Matching: tap left, then right; a right pair is read (`sayFor`). */
export function MatchExercise(props:StepProps&{kicker:string;title:string;lead?:string;pairs:readonly (readonly [string,string])[];sayFor:(index:number)=>SayItem[]}){
 const {speech,sound,pairs,sayFor,kicker,title,lead='Önce soldan, sonra sağdan dokun.'}=props;const finish=useFinish(props);
 const [order]=useState(()=>shuffle(pairs.map((_,i)=>i)));
 const [selected,setSelected]=useState<number|null>(null);const [done,setDone]=useState<number[]>([]);const [wrongAt,setWrongAt]=useState<number|null>(null);const [misses,setMisses]=useState(0);
 const [feedback,setFeedback]=useState<Feedback>(null);
 const pickRight=(i:number)=>{
  if(selected===null||done.includes(i))return;sound.prepare();speech.prepare();
  if(i===selected){const next=[...done,i];setDone(next);setSelected(null);speech.speakAll(sayFor(i));
   if(next.length===pairs.length){const right=Math.max(0,pairs.length-misses);setFeedback({ok:true,text:'Hepsi eşleşti!'});finish(right,pairs.length,undefined,true);}}
  else{setWrongAt(i);setMisses(m=>m+1);setFeedback({ok:false,text:'Bu ikisi uymuyor.'});sound.wrong();setTimeout(()=>setWrongAt(null),600);}
 };
 return <>
  <p className="kicker" lang="de">{kicker}</p><Heading>{title}</Heading><p className="l1a-tr">{lead}</p>
  <div className="l1a-match">
   <div>{pairs.map((pair,i)=><button type="button" key={i} className={'l1a-mbtn'+(selected===i?' sel':'')+(done.includes(i)?' done':'')} disabled={done.includes(i)} aria-pressed={selected===i} lang="de" dir="ltr" onClick={()=>setSelected(i)}>{pair[0]}</button>)}</div>
   <div>{order.map(i=><button type="button" key={i} className={'l1a-mbtn'+(done.includes(i)?' done':'')+(wrongAt===i?' bad':'')} disabled={done.includes(i)} lang="de" dir="ltr" onClick={()=>pickRight(i)}>{pairs[i][1]}</button>)}</div>
  </div>
  <FeedbackLine feedback={feedback}/>
 </>;
}
/** Word order: tap the chips in order; a right sentence is read (`sayFor`); `verbs` names the verb in position 2 in the feedback.
 * `word`: the chips are the syllables of one long word (Lektion 2D), shown joined; `goalLabel` replaces "Bu cümleyi kur:"
 * above the goal; `strict` (a points test, Lektion 2D Alles klar?): a sentence counts only when it was built without a
 * wrong check and without İpucu. */
export function OrderExercise(props:StepProps&{kicker:string;title:string;sentences:string[][];sayFor:(sentence:string)=>SayItem;verbs?:string[];meanings?:string[];goalLabel?:string;word?:boolean;strict?:boolean}){
 const {speech,sound,sentences:orderSentences,sayFor:orderSay,kicker,title,verbs,meanings,goalLabel,word=false,strict=false,runKey,step}=props;const finish=useFinish(props);
 const deal=(r:number)=>shuffle(orderSentences[r].map((word,i)=>({word,i})));
 // A sentence game left in the middle goes on at its sentence; a solved sentence goes on at the next one.
 type Run={round:number;right:number;picked:number[];chips:{word:string;i:number}[];state:'open'|'ok'|'bad';miss?:boolean};
 const [saved]=useState(()=>readRun<Run>(runKey,step.id,value=>{
  const round=Number(value.round),right=Number(value.right);if(!(round>=0&&round<orderSentences.length)||!(right>=0&&right<=round+1))return null;
  const chips=Array.isArray(value.chips)?value.chips as Run['chips']:[];if(chips.map(chip=>chip.word).sort().join(' ')!==orderSentences[round].slice().sort().join(' '))return null;
  if(value.state==='ok')return round+1<orderSentences.length?{round:round+1,right,picked:[],chips:deal(round+1),state:'open'}:null;
  const picked=Array.isArray(value.picked)?(value.picked as number[]).filter(i=>chips.some(chip=>chip.i===i)):[];
  return {round,right,picked,chips,state:value.state==='bad'?'bad':'open',miss:!!value.miss};
 }));
 const [round,setRound]=useState(saved?.round??0);const [chips,setChips]=useState<{word:string;i:number}[]>(()=>saved?.chips??deal(0));
 const [picked,setPicked]=useState<number[]>(saved?.picked??[]);const [state,setState]=useState<'open'|'ok'|'bad'>(saved?.state??'open');const [right,setRight]=useState(saved?.right??0);const [feedback,setFeedback]=useState<Feedback>(null);
 const [miss,setMiss]=useState(saved?.miss??false);
 const sentence=orderSentences[round];const text=picked.map(i=>sentence[i]).join(word?'':' ');
 const ended=state==='ok'&&round===orderSentences.length-1;
 useRunSave(runKey,step.id,!ended&&(round>0||picked.length>0||state!=='open')?{round,right,picked,chips,state,...(strict?{miss}:{})}:null);
 const check=()=>{sound.prepare();speech.prepare();const ok=picked.length===sentence.length&&picked.every((p,k)=>sentence[p]===sentence[k]);setState(ok?'ok':'bad');
  if(ok){const total=right+(strict&&miss?0:1);setRight(total);setFeedback({ok:true,text:round===orderSentences.length-1?(word?'Tüm kelimeler doğru!':'Tüm cümleler doğru!'):verbs?.[round]?`Doğru! Fiil „${verbs[round]}“ 2. pozisyonda.`:'Doğru!'});
   // The sound goes by this last answer (a points test may still have lost a point on an earlier try).
   if(round===orderSentences.length-1)finish(total,orderSentences.length,[orderSay(sentence.join(' '))],true);else sound.correct(()=>speech.speak(orderSay(sentence.join(' '))));}
  else{if(strict)setMiss(true);setFeedback({ok:false,text:verbs?'Fiil 2. sırada mı? Sırayı kontrol et.':'Sırayı kontrol et.'});sound.wrong();}};
 const next=()=>{const r=round+1;setRound(r);setChips(deal(r));setPicked([]);setState('open');setMiss(false);setFeedback(null);};
 // İpucu (the learner asked, 2 November 2026): a wrong word at the end is taken back and the next right word is put in.
 const hint=()=>{if(state==='ok')return;sound.prepare();
  let keep=0;while(keep<picked.length&&sentence[picked[keep]]===sentence[keep])keep++;
  const kept=picked.slice(0,keep);if(keep>=sentence.length){setPicked(kept);return;}
  if(strict)setMiss(true);
  const chip=chips.find(item=>item.word===sentence[keep]&&!kept.includes(item.i));if(!chip)return;
  setPicked([...kept,chip.i]);setState('open');setFeedback({ok:true,info:true,text:'İpucu: sıradaki kelime „'+sentence[keep]+'“.'});};
 // İleri at the bottom: the next sentence once this one is right (a tap by mistake loses nothing); after the last one the next step.
 useInnerNext(props.setInnerNext,()=>{
  if(ended)return false;
  if(state==='ok'){next();return true;}
  setFeedback({ok:false,text:word?'Önce kelimeyi kur.':'Önce cümleyi kur.'});return true;
 });
 return <>
  <p className="kicker" lang="de">{kicker}</p><Heading>{title}</Heading><p className="l1a-tr">{word?'Kelime':'Cümle'} {round+1} / {orderSentences.length}</p>
  {meanings?.[round]&&<p className="l1a-order-goal">{goalLabel?<>{goalLabel} <b lang="de">{meanings[round]}</b></>:word?<>Bu kelimeyi kur: <b>{meanings[round]}</b></>:<>Bu cümleyi kur: <b>{meanings[round]}</b></>}</p>}
  <div className={'l1a-answer'+(state==='ok'?' ok':state==='bad'?' bad':'')} lang="de" dir="ltr" aria-live="polite">{text}</div>
  <div className="l1a-chips">{chips.map(chip=><button type="button" key={chip.i} className="l1a-chip" lang="de" dir="ltr" disabled={picked.includes(chip.i)||state==='ok'} onClick={()=>{setPicked([...picked,chip.i]);setState('open');}}>{chip.word}</button>)}</div>
  <div className="l1a-actions">
   <button type="button" className="btn secondary small" disabled={!picked.length||state==='ok'} onClick={()=>{setPicked(picked.slice(0,-1));setState('open');}}><Trash2 size={16} aria-hidden="true"/>Sil</button>
   <button type="button" className="btn secondary small" disabled={state==='ok'||picked.length===sentence.length&&picked.every((p,k)=>sentence[p]===sentence[k])} onClick={hint}><Lightbulb size={16} aria-hidden="true"/>İpucu</button>
   <button type="button" className="btn small" disabled={picked.length!==sentence.length||state==='ok'} onClick={check}><Check size={16} aria-hidden="true"/>Kontrol et</button>
   {state==='ok'&&round<orderSentences.length-1&&<button type="button" className="btn small" onClick={next}>Sonraki<ArrowRight size={16} className="vault-direction-icon" aria-hidden="true"/></button>}
  </div>
  <FeedbackLine feedback={feedback}/>
 </>;
}
/** One choice per row (Sie or du, which letter, right or not …): the row is read after the answer (`say`), and
 * `reveal` appears once the row is answered. */
export type ChoiceRow={key:string;before?:ReactNode;after?:ReactNode;options:{value:string;label:string}[];answer:string;say?:SayItem;reveal?:ReactNode;label:string;optionLang?:string};
export function ChoiceRows(props:StepProps&{kicker:string;title:string;lead?:string;before?:ReactNode;rows:ChoiceRow[];wide?:boolean}){
 const {speech,sound,rows,kicker,title,lead,before,wide=false}=props;const finish=useFinish(props);
 // Rows with their own choices are mixed (the learner asked, 30 October 2026); one fixed pair for every row (du / Sie,
 // Ach / Ich, Ja / Nein) keeps its order.
 const [orders]=useState(()=>{const key=(row:ChoiceRow)=>row.options.map(option=>option.value).join('\u0001');const fixed=rows.every(row=>key(row)===key(rows[0]));return rows.map(row=>fixed?row.options:shuffle(row.options));});
 const [answers,setAnswers]=useState<Record<number,string>>({});const [feedback,setFeedback]=useState<Feedback>(null);
 const answer=(i:number,value:string)=>{if(answers[i]!==undefined)return;sound.prepare();speech.prepare();
  const next={...answers,[i]:value};setAnswers(next);const row=rows[i];const ok=value===row.answer;
  const done=Object.keys(next).length;const right=rows.filter((item,j)=>next[j]===item.answer).length;
  const say=()=>{if(row.say)speech.speak(row.say);};
  if(done===rows.length){setFeedback(scoreFeedback(right,rows.length));finish(right,rows.length,row.say?[row.say]:undefined,ok);}
  else if(ok)sound.correct(say);else sound.wrong(say);};
 return <>
  <p className="kicker" lang="de">{kicker}</p><Heading>{title}</Heading>{lead&&<p className="l1a-tr">{lead}</p>}{before}
  {rows.map((row,i)=><div className={'l1a-arow'+(wide?' wide':'')} key={row.key} data-done={answers[i]!==undefined?'':undefined}>
   {row.before}
   <div className="l1a-opts" role="group" aria-label={row.label}>{(orders[i]??row.options).map(option=><button type="button" key={option.value} className={'l1a-opt'+(answers[i]!==undefined&&option.value===row.answer?' ok':answers[i]===option.value?' bad':'')} disabled={answers[i]!==undefined} lang={row.optionLang??'de'} onClick={()=>answer(i,option.value)}>{option.label}</button>)}</div>
   {row.after}
   {answers[i]!==undefined&&row.reveal}
  </div>)}
  <FeedbackLine feedback={feedback}/>
 </>;
}
/** The test: one question at a time, the right answer is read after the sound (`sayFor`, nothing for a Turkish answer).
 * `listen`: a listening question gets a listen button (Lektion 15A); `langOf`: the language of a question or option
 * when the lesson knows it better than the guess below. */
export function TestStep(props:StepProps&{label:string;questions:readonly (readonly [string,string[],string,...unknown[]])[];sayFor:(index:number)=>SayItem;listen?:(index:number)=>SayItem|undefined;langOf?:(text:string)=>'de'|'tr'}){
 const {speech,sound,onScore,step,questions,sayFor,label,listen,langOf,runKey}=props;
 // A test left in the middle goes on at its question (the learner asked, 30 October 2026); an answered question goes on at the next one.
 type Run={i:number;score:number;picked:string|null;options:string[]};
 const [saved]=useState(()=>readRun<Run>(runKey,step.id,value=>{
  const i=Number(value.i),score=Number(value.score);if(!(i>=0&&i<questions.length)||!(score>=0&&score<=i+1))return null;
  if(typeof value.picked==='string')return i+1<questions.length?{i:i+1,score,picked:null,options:shuffle(questions[i+1][1])}:null;
  return sameItems(value.options,questions[i][1])?{i,score,picked:null,options:value.options as string[]}:null;
 }));
 const [i,setI]=useState(saved?.i??0);const [score,setScore]=useState(saved?.score??0);const [picked,setPicked]=useState<string|null>(null);const [options,setOptions]=useState(()=>saved?.options??shuffle(questions[0][1]));const [over,setOver]=useState(false);
 const [wait,setWait]=useState(false);
 useRunSave(runKey,step.id,!over&&(i>0||picked!==null)?{i,score,picked,options}:null);
 const timer=useRef<ReturnType<typeof setTimeout>|null>(null);
 // Leaving right after the last answer still saves the result.
 const pending=useRef<(()=>void)|null>(null);
 useEffect(()=>()=>{if(timer.current)clearTimeout(timer.current);pending.current?.();},[]);
 const question=questions[i];
 const answer=(option:string)=>{if(picked!==null)return;sound.prepare();speech.prepare();setPicked(option);setWait(false);const ok=option===question[2];const total=score+(ok?1:0);setScore(total);
  const say=sayFor(i);const after=()=>{if(say)speech.speak(say);};if(ok)sound.correct(after);else sound.wrong(after);
  if(i+1>=questions.length)pending.current=()=>onScore(step.id,total,questions.length);
  timer.current=setTimeout(()=>advance(i,total),1600);};
 /** The next question (or the result after the last one). */
 const advance=(from:number,total:number)=>{if(timer.current){clearTimeout(timer.current);timer.current=null;}pending.current=null;
  if(from+1<questions.length){setI(from+1);setPicked(null);setOptions(shuffle(questions[from+1][1]));}else{setOver(true);onScore(step.id,total,questions.length);if(total===questions.length)sound.complete();}};
 // İleri at the bottom (the learner asked, 30 October 2026): the next question once this one is answered; a tap by
 // mistake before answering loses nothing. On the result page İleri opens the next step.
 useInnerNext(props.setInnerNext,()=>{if(over)return false;if(picked===null){setWait(true);return true;}advance(i,score);return true;});
 const again=()=>{setI(0);setScore(0);setPicked(null);setOptions(shuffle(questions[0][1]));setOver(false);setWait(false);};
 if(over){const percent=Math.round(score/questions.length*100);return <>
  <p className="kicker" lang="de">{label}</p><Heading>Sonuç</Heading>
  <p className="l1a-score">{score} / {questions.length}</p>
  <p className="l1a-big">{percent>=80?'Harika! Bu konuyu öğrendin.':percent>=60?'İyi. Yanlışlarına bir daha bak.':'Konuyu bir kez daha oku, sonra tekrar dene.'}</p>
  {percent>=80&&<PaulHoca pose="cheer" className="l1a-paul-big"/>}
  <div className="l1a-actions"><button type="button" className="btn" onClick={again}><RotateCcw size={18} aria-hidden="true"/>Testi tekrarla</button></div></>;}
 return <>
  <p className="kicker" lang="de">{label}</p><Heading>Soru {i+1} / {questions.length}</Heading>
  <p className="l1a-question" lang={langOf?langOf(question[0]):/[çğışİ]|hangisi|nedir|nasıl|ne demek|cevap/.test(question[0])?'tr':'de'}>{question[0]}</p>
  {(()=>{const heard=listen?.(i);return heard?<div className="l1a-actions l1a-test-listen"><Say text={typeof heard==='string'?heard:heard.text} who={typeof heard==='string'?undefined:heard.who} speech={speech} secret wide/></div>:null;})()}
  <div className="l1a-opts column" role="group" aria-label={'Soru '+(i+1)}>{options.map(option=><button type="button" key={option} className={'l1a-opt'+(picked!==null&&option===question[2]?' ok':picked===option?' bad':'')} disabled={picked!==null} lang={langOf?langOf(option):/^[A-Za-zÄÖÜäöüß–]/.test(option)&&!/^(Hoş|İyi|Teşekkürler|Efendim|Nasıl|biraz|çok|hiç|yot|ce|ji)\b/.test(option)?'de':'tr'} onClick={()=>answer(option)}>{option}</button>)}</div>
  <p className="l1a-mini">Puan: {score}</p>
  {wait&&<p className="l1a-feedback bad" role="status">Önce bir cevap seç.</p>}
 </>;
}

/** The steps of the open index tab as a strip of small pills under the tabs (the learner chose it, 30 October 2026):
 * scroll it with a finger, or with the mouse wheel on a computer; a tap opens a step. A done exercise shows a tick.
 * `track`: the same steps inside the card's blue progress bar instead (the learner chose it, 30 October 2026, option C):
 * done steps and the open step are filled blue; an edge fades only where more steps are hidden behind it. */
export type StripItem={id:string;index:number;number:number;label:string;locked?:boolean};
export function StepStrip({items,current,scores,onOpen,label,track=false}:{items:StripItem[];current:string;scores:L1AScoreMap;onOpen:(index:number)=>void;label:string;track?:boolean}){
 const row=useRef<HTMLDivElement>(null);
 useEffect(()=>{const element=row.current;if(!element)return;const on=element.querySelector<HTMLElement>('.l1a-strip-pill.on');if(on)element.scrollLeft=on.offsetLeft-(element.clientWidth-on.offsetWidth)/2;},[current]);
 useEffect(()=>{const element=row.current;if(!element)return;const wheel=(event:WheelEvent)=>{if(Math.abs(event.deltaY)>Math.abs(event.deltaX)&&element.scrollWidth>element.clientWidth){element.scrollLeft+=event.deltaY;event.preventDefault();}};element.addEventListener('wheel',wheel,{passive:false});return()=>element.removeEventListener('wheel',wheel);},[]);
 useEffect(()=>{const element=row.current;if(!element||!track)return;
  // Which edges hide more steps (in a right-to-left language the strip starts on the right and scrollLeft goes negative).
  const edges=()=>{const hidden=element.scrollWidth-element.clientWidth;const moved=Math.abs(element.scrollLeft);const rtl=getComputedStyle(element).direction==='rtl';
   element.toggleAttribute('data-fade-left',(rtl?hidden-moved:moved)>2);element.toggleAttribute('data-fade-right',(rtl?moved:hidden-moved)>2);};
  edges();element.addEventListener('scroll',edges,{passive:true});window.addEventListener('resize',edges);
  return()=>{element.removeEventListener('scroll',edges);window.removeEventListener('resize',edges);};
 },[track,current]);
 return <nav className={'l1a-strip'+(track?' l1a-track':'')} ref={row} aria-label={label}>{items.map(item=>{const done=!!scores[item.id]&&item.id!==current;return <button type="button" key={item.id} className={'l1a-strip-pill'+(item.id===current?' on':'')+(done?' done':'')+(item.locked?' locked':'')} aria-current={item.id===current?'step':undefined} title={item.locked?'Önce önceki alıştırmaları bitir':undefined} onClick={()=>onOpen(item.index)}><b aria-hidden="true">{item.locked?<Lock size={12}/>:done?<Check size={13}/>:item.number}</b>{item.label}</button>;})}</nav>;
}
